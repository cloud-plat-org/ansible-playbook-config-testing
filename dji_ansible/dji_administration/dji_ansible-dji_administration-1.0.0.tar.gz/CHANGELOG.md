# Changelog

## [1.0.0] - 2025-10-01

### Added
- Initial release of dji_ansible.dji_administration collection
- service_mgmt role for managing system services
